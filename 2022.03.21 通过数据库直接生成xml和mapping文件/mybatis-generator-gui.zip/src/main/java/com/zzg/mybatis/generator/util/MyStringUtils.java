package com.zzg.mybatis.generator.util;

import org.apache.commons.lang3.StringUtils;

/**
 * Created by Owen on 6/18/16.
 */
public class MyStringUtils {
    private static final String TABLE_NAME_PREFIX = "icssas";
    /**
     * convert string from slash style to camel style, such as my_course will convert to MyCourse
     *
     * @param str
     * @return
     */
    public static String dbStringToCamelStyle(String str) {
        if (StringUtils.isBlank(str)) {
            throw new NullPointerException();
        }

        if (!str.contains("_")) {
            String firstChar = String.valueOf(str.charAt(0)).toUpperCase();
            String otherChars = str.substring(1);
            return firstChar + otherChars;
        }

        str = str.toLowerCase();
        StringBuilder sb = new StringBuilder();

        //删除前缀
        str = deletePrefix(str);

        sb.append(String.valueOf(str.charAt(0)).toUpperCase());
        for (int i = 1; i < str.length(); i++) {
            char c = str.charAt(i);
            if (c != '_') {
                sb.append(c);
            } else {
                if (i + 1 < str.length()) {
                    sb.append(String.valueOf(str.charAt(i + 1)).toUpperCase());
                    i++;
                }
            }
        }
        return sb.toString();
    }

    private static String deletePrefix(String str) {
        if (str.indexOf(TABLE_NAME_PREFIX) == 0) {
            str = str.substring(TABLE_NAME_PREFIX.length() + 1);
        }
        return str;
    }

}
